#ifndef __VECTOR_HPP__
#define __VECTOR_HPP__

#include <cstdlib>
#include <new>

// Constructor
template <typename T>
vector_t<T>::vector_t(void) :
    array(0),
    array_size(0),
    num_elements(0) {
    // Nothing to do
}

// Get the number of elements in the array.
template <typename T>
inline size_t vector_t<T>::size(void) const { return num_elements; }

// Get the allocated array size in the unit of elements.
template <typename T>
inline size_t vector_t<T>::capacity(void) const { return array_size; }

// Get a reference of the element at the given index.
template <typename T>
inline T& vector_t<T>::operator[](const size_t m_index) const { return array[m_index]; }

// Get an iterator pointing to the first element of the array.
template <typename T>
inline typename vector_t<T>::iterator vector_t<T>::begin(void) const {
    return iterator_t<T>(array);
}

// Get an iterator pointing to the next of the last element.
template <typename T>
inline typename vector_t<T>::iterator vector_t<T>::end(void) const {
    return iterator_t<T>(array+num_elements);
}


/* Assignment 2: C++ Template
   Fill in the following functions of the template class.
 */


// Copy constructor
template <typename T>
vector_t<T>::vector_t(const vector_t<T> &m_vector) {
    /* Assignment */
}

// Destructor
template <typename T>
vector_t<T>::~vector_t(void) {
    /* Assignment */
}

// Reserve an array space for the given number of elements.
template <typename T>
void vector_t<T>::reserve(size_t m_array_size) {
    /* Assignment */
}

// Resize the array to have the given number of elements.
template <typename T>
void vector_t<T>::resize(size_t m_num_elements, T m_data) {
    /* Assignment */
}

// Remove all elements in the array.
template <typename T>
void vector_t<T>::clear(void) {
    /* Assignment */
}

// Add a new element at the end of the array.
template <typename T>
void vector_t<T>::push_back(const T &m_data) {
    /* Assignment */
}

// Remove the last element in the array.
template <typename T>
void vector_t<T>::pop_back(void) {
    /* Assignment */
}

// Assign new contents to the array.
template <typename T>
vector_t<T>& vector_t<T>::operator=(const vector_t<T>& m_vector) {
    /* Assignment */
    return *this;               // This is to avoid a compile error in the skeleton code.
}

// Add a new element at the location pointed by the iterator.
template <typename T>
typename vector_t<T>::iterator vector_t<T>::insert(vector_t<T>::iterator m_it,
                                                   const T &m_data) {
    /* Assignment */
    return iterator_t<T>(0);    // This is to avoid a compile error in the skeleton code.
}

// Erase an element at the location pointed by the iterator.
template <typename T>
typename vector_t<T>::iterator vector_t<T>::erase(vector_t<T>::iterator m_it) {
    /* Assignment */
    return iterator_t<T>(0);    // This is to avoid a compile error in the skeleton code.
}

#endif
